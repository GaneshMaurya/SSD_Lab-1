SSD Assignment 1

Question-1
1. Run a while loop and run through all the lines present in access.log file
2. for each line use grep command to check if it contains 'POST' and then pass this output into another grep and check if it contains '404'
3. Thus the output is printed

Question-2
1. Use awk and separate values through delimiter
2. Sum up all the values present in the 4th column using awk